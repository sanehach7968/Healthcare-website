const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = 3000;
const dataFolder = path.join(__dirname, "data");

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

function saveData(file, item) {
  const filePath = path.join(dataFolder, file);
  const items = JSON.parse(fs.readFileSync(filePath, "utf8"));
  items.push(item);
  fs.writeFileSync(filePath, JSON.stringify(items, null, 2));
}

const doctors = [
  { id: 1, name: "Dr. Asha Mehta", specialty: "General Physician", area: "Ludhiana", fee: 400 },
  { id: 2, name: "Dr. Kabir Sharma", specialty: "Dermatologist", area: "Chandigarh", fee: 600 },
  { id: 3, name: "Dr. Neha Verma", specialty: "Pediatrician", area: "Mohali", fee: 500 },
  { id: 4, name: "Dr. Arjun Singh", specialty: "ENT Specialist", area: "Ludhiana", fee: 450 },
  { id: 5, name: "Dr. Simran Kaur", specialty: "General Physician", area: "Mohali", fee: 350 }
];

const products = [
  { id: 1, name: "ORS Sachets", price: 20, description: "Hydration support product" },
  { id: 2, name: "Saline Nasal Spray", price: 90, description: "Nasal comfort product" },
  { id: 3, name: "Digital Thermometer", price: 150, description: "For checking temperature" },
  { id: 4, name: "First Aid Bandages", price: 50, description: "Basic first-aid supplies" }
];

app.get("/api/doctors", (req, res) => {
  const area = (req.query.area || "").toLowerCase();
  const specialty = (req.query.specialty || "").toLowerCase();
  const result = doctors.filter(d =>
    d.area.toLowerCase().includes(area) &&
    d.specialty.toLowerCase().includes(specialty)
  );
  res.json(result);
});

app.get("/api/products", (_req, res) => res.json(products));

app.post("/api/check-symptoms", (req, res) => {
  const symptoms = String(req.body.symptoms || "").toLowerCase();
  if (!symptoms.trim()) {
    return res.status(400).json({ message: "Please enter your symptoms." });
  }

  if (["chest pain", "difficulty breathing", "cannot breathe", "unconscious", "severe bleeding"].some(s => symptoms.includes(s))) {
    return res.json({
      title: "Urgent medical help may be needed",
      message: "This website cannot assess emergencies. Call India's emergency number 112 or go to the nearest emergency department now.",
      advice: ["Do not wait for an online appointment."]
    });
  }

  let result = {
    title: "Please consider speaking with a doctor",
    message: "Many conditions can cause similar symptoms. This demo cannot confirm a disease.",
    advice: ["Rest and drink fluids if appropriate.", "Seek medical advice if symptoms continue, worsen, or concern you."]
  };

  if (/fever|temperature|chills/.test(symptoms)) {
    result = {
      title: "Fever-related symptoms",
      message: "Fever can have many causes. This is general information, not a diagnosis.",
      advice: ["Monitor your temperature and drink fluids if you can.", "Ask a qualified clinician or pharmacist before using medicine."]
    };
  } else if (/cough|cold|sore throat|runny nose/.test(symptoms)) {
    result = {
      title: "Cold-like symptoms",
      message: "These symptoms may have several causes. This demo cannot identify which condition you have.",
      advice: ["Rest and drink fluids.", "Seek medical advice if symptoms worsen or breathing becomes difficult."]
    };
  } else if (/itch|rash|skin|acne/.test(symptoms)) {
    result = {
      title: "Skin-related symptoms",
      message: "Skin problems can have many causes. A clinician can help identify the right treatment.",
      advice: ["Avoid using prescription creams without medical advice.", "Seek urgent help for facial swelling or trouble breathing."]
    };
  }

  res.json(result);
});

app.post("/api/appointments", (req, res) => {
  const { name, phone, doctorId, date, mode } = req.body;
  const doctor = doctors.find(d => d.id === Number(doctorId));
  if (!name || !phone || !doctor || !date || !mode) {
    return res.status(400).json({ message: "Please complete all appointment fields." });
  }
  const booking = {
    reference: "APT-" + Date.now(),
    name, phone, doctor: doctor.name, date, mode,
    status: "Demo request saved"
  };
  saveData("appointments.json", booking);
  res.json({ message: "Demo request saved. This is not a confirmed appointment.", booking });
});

app.post("/api/delivery", (req, res) => {
  const { name, phone, area, address, items } = req.body;
  if (!name || !phone || !area || !address || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ message: "Complete your details and add at least one item." });
  }
  const total = items.reduce((sum, item) => {
    const product = products.find(p => p.id === Number(item.id));
    return sum + (product ? product.price * Number(item.quantity || 1) : 0);
  }, 0);
  const order = {
    reference: "MED-" + Date.now(), name, phone, area, address, items, total,
    status: "Demo request saved — no delivery will be made"
  };
  saveData("delivery-requests.json", order);
  res.json({ message: "Demo delivery request saved. No pharmacy has been contacted.", order });
});

app.listen(PORT, () => console.log("CareBridge is running at http://localhost:" + PORT));
