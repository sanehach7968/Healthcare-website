CAREBRIDGE BASIC HEALTHCARE WEBSITE

Requirements:
- Node.js installed on your computer
- Internet is not needed for the basic site itself

HOW TO RUN:
1. Extract the ZIP file.
2. Open the extracted CareBridge_Basic folder in VS Code.
3. Open Terminal > New Terminal.
4. Run: npm install
5. Run: npm start
6. Open Chrome and visit: http://localhost:3000

Project structure:
- server.js: Express backend and APIs
- public/index.html: website page
- public/style.css: website design
- public/script.js: interactive features
- data/appointments.json: saved demo appointment requests
- data/delivery-requests.json: saved demo delivery requests

IMPORTANT:
This is a college-project demonstration, not a real medical service.
The symptom checker provides general guidance only. It does not diagnose
disease or prescribe medicine. Doctor profiles and prices are fictional.
Appointment and delivery forms only save demo requests; no doctor or pharmacy
is contacted and nothing is delivered. Do not enter real sensitive information.
