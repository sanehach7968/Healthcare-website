let doctors = [];
let products = [];
let cart = [];

async function request(url, options = {}) {
  const response = await fetch(url, {
    headers: { "Content-Type": "application/json" },
    ...options
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.message || "Request failed");
  return data;
}

function fillSymptom(text) {
  document.getElementById("symptomInput").value = text;
}

async function checkSymptoms() {
  const symptoms = document.getElementById("symptomInput").value.trim();
  const result = document.getElementById("symptomResult");
  if (!symptoms) {
    result.innerHTML = "<h3>Please enter your symptoms</h3><p>Describe how you are feeling first.</p>";
    return;
  }
  try {
    const data = await request("/api/check-symptoms", {
      method: "POST",
      body: JSON.stringify({ symptoms })
    });
    result.innerHTML = `<div class="big-icon">♡</div><h3>${escapeText(data.title)}</h3><p>${escapeText(data.message)}</p><ul>${data.advice.map(item => `<li>${escapeText(item)}</li>`).join("")}</ul><p><b>This is general guidance, not a diagnosis or prescription.</b></p>`;
  } catch (error) {
    result.innerHTML = `<p>${escapeText(error.message)}</p>`;
  }
}

function escapeText(value) {
  return String(value).replace(/[&<>"']/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[c]));
}

async function loadDoctors() {
  const area = document.getElementById("area").value.trim();
  const specialty = document.getElementById("specialty").value;
  const params = new URLSearchParams({ area, specialty });
  const list = document.getElementById("doctorList");
  try {
    doctors = await request("/api/doctors?" + params);
    if (!doctors.length) {
      list.innerHTML = "<p>No sample profiles found. Try another area or specialty.</p>";
      updateDoctorSelect();
      return;
    }
    list.innerHTML = doctors.map(d => `
      <div class="doctor-card">
        <h3>${escapeText(d.name)}</h3>
        <p>${escapeText(d.specialty)} · ${escapeText(d.area)}</p>
        <p class="fee">₹${d.fee} <small>sample fee</small></p>
        <button onclick="selectDoctor(${d.id})">Request appointment</button>
        <p>Fictional sample profile — not a verified real doctor.</p>
      </div>`).join("");
    updateDoctorSelect();
  } catch (error) {
    list.innerHTML = `<p>${escapeText(error.message)}</p>`;
  }
}

function updateDoctorSelect() {
  document.getElementById("doctorSelect").innerHTML =
    '<option value="">Choose doctor</option>' +
    doctors.map(d => `<option value="${d.id}">${escapeText(d.name)} - ${escapeText(d.specialty)}</option>`).join("");
}

function selectDoctor(id) {
  document.getElementById("doctorSelect").value = String(id);
  document.getElementById("appointment").scrollIntoView({ behavior: "smooth" });
}

async function loadProducts() {
  products = await request("/api/products");
  document.getElementById("productList").innerHTML = products.map(p => `
    <div class="product-card">
      <h3>${escapeText(p.name)}</h3><p>${escapeText(p.description)}</p>
      <div class="price">₹${p.price}</div>
      <button onclick="addToCart(${p.id})">Add to cart</button>
    </div>`).join("");
}

function addToCart(id) {
  const item = cart.find(x => x.id === id);
  if (item) item.quantity++;
  else cart.push({ id, quantity: 1 });
  renderCart();
}

function removeFromCart(id) {
  cart = cart.filter(item => item.id !== id);
  renderCart();
}

function renderCart() {
  const count = cart.reduce((sum, item) => sum + item.quantity, 0);
  const total = cart.reduce((sum, item) => {
    const product = products.find(p => p.id === item.id);
    return sum + product.price * item.quantity;
  }, 0);
  document.getElementById("cartSummary").textContent = count ? `${count} item(s) in demo cart` : "Your cart is empty.";
  document.getElementById("cartTotal").textContent = total;
  document.getElementById("cartItems").innerHTML = cart.map(item => {
    const product = products.find(p => p.id === item.id);
    return `<div class="cart-line"><span>${escapeText(product.name)} × ${item.quantity}</span><span>₹${product.price * item.quantity} <button type="button" onclick="removeFromCart(${item.id})">Remove</button></span></div>`;
  }).join("");
}

document.getElementById("appointmentForm").addEventListener("submit", async event => {
  event.preventDefault();
  const message = document.getElementById("appointmentMessage");
  const form = event.currentTarget;
  const payload = Object.fromEntries(new FormData(form).entries());
  payload.doctorId = Number(payload.doctorId);
  try {
    const data = await request("/api/appointments", { method: "POST", body: JSON.stringify(payload) });
    message.textContent = `${data.message} Reference: ${data.booking.reference}`;
    form.reset();
  } catch (error) {
    message.textContent = error.message;
  }
});

document.getElementById("deliveryForm").addEventListener("submit", async event => {
  event.preventDefault();
  const message = document.getElementById("deliveryMessage");
  if (!cart.length) {
    message.textContent = "Please add at least one item to the cart.";
    return;
  }
  const form = event.currentTarget;
  const payload = Object.fromEntries(new FormData(form).entries());
  payload.items = cart;
  try {
    const data = await request("/api/delivery", { method: "POST", body: JSON.stringify(payload) });
    message.textContent = `${data.message} Reference: ${data.order.reference}. Total: ₹${data.order.total}.`;
    cart = [];
    renderCart();
    form.reset();
  } catch (error) {
    message.textContent = error.message;
  }
});

document.getElementById("dateInput").min = new Date().toISOString().slice(0, 10);
Promise.all([loadDoctors(), loadProducts()]).catch(error => console.error(error));
